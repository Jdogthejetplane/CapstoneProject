#Database -- Docker
For convenience, there is a Makefile in the project folder. There are 5 common commands for troubleshooting that are assigned to keywords that can be used as so:
    make up
    make logs
    make sql
    make seed
    make down

Since we are using the predefined MariaDB image, no dockerfile is needed. The YAML file does all the networking. 

To start container, run "docker compose up -d" in the project folder. 

To access the database from the terminal, run "docker compose exec db mariadb -u root -p sad".
Password -- "UApass4445"



#Adminer
Adminer allows us to alter database tables, rows, fields etc through a web UI. To access this, run the docker container as shown above, and go to browser and enter "localhost:8080". 

username -- "root"
password -- "UApass4445"
database -- "sad"



#SQL Initialization
All the tables and fields were initialized according to the ERD. The "seed" is used to populate the tables with information on startup. 

'charset.cnf' simply makes all SQL tables use Unicode by default so we don't have to specify it. 
