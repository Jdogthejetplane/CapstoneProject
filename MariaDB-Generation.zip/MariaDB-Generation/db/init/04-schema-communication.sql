SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE IF NOT EXISTS events (
  event_id CHAR(36) PRIMARY KEY,
  kind VARCHAR(64),
  payload JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS notifications (
  notification_id CHAR(36) PRIMARY KEY,
  type VARCHAR(64) NOT NULL,
  message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  is_read BOOLEAN DEFAULT 0,
  target_users_id CHAR(36),
  source_events_id CHAR(36),
  CONSTRAINT fk_notifications_user FOREIGN KEY (target_users_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_notifications_event FOREIGN KEY (source_events_id) REFERENCES events(event_id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;
SET FOREIGN_KEY_CHECKS=1;
