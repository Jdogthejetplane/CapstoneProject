SET NAMES utf8mb4; SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE IF NOT EXISTS colleges (
  college_id CHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  address VARCHAR(255),
  transcripConnect VARCHAR(255),
  majorConnection VARCHAR(255),
  classConnection VARCHAR(255)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS users (
  user_id CHAR(36) PRIMARY KEY,
  role VARCHAR(32) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255),
  fname VARCHAR(120),
  lname VARCHAR(120),
  college_id CHAR(36),
  CONSTRAINT fk_users_college FOREIGN KEY (college_id) REFERENCES colleges(college_id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS leaders (
  leader_id CHAR(36) PRIMARY KEY,
  user_id CHAR(36) NOT NULL UNIQUE,
  CONSTRAINT fk_leaders_user FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS advisors (
  advisor_id CHAR(36) PRIMARY KEY,
  user_id CHAR(36) NOT NULL UNIQUE,
  percent_advised DECIMAL(5,2),
  rating DECIMAL(5,2),
  CONSTRAINT fk_advisors_user FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS students (
  student_id CHAR(36) PRIMARY KEY,
  user_id CHAR(36) NOT NULL UNIQUE,
  credit_hrs INT,
  gpa DECIMAL(3,2),
  advising_status VARCHAR(64),
  last_advised DATETIME,
  activity TEXT,
  transcript_id CHAR(36),
  scholarship_ids VARCHAR(255),
  CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
SET FOREIGN_KEY_CHECKS=1;
