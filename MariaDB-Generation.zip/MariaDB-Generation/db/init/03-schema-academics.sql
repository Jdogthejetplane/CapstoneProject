SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE IF NOT EXISTS courses (
  course_id CHAR(36) PRIMARY KEY,
  college_id CHAR(36),
  code VARCHAR(64) NOT NULL,
  title VARCHAR(255) NOT NULL,
  credits INT NOT NULL,
  difficulty INT,
  CONSTRAINT fk_courses_college FOREIGN KEY (college_id) REFERENCES colleges(college_id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  UNIQUE KEY uq_course_code (code)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS classes (
  id CHAR(36) PRIMARY KEY,
  course_id CHAR(36) NOT NULL,
  year DATE,
  semester VARCHAR(32),
  length INT,
  time TIME,
  location VARCHAR(255),
  teacher VARCHAR(255),
  CONSTRAINT fk_classes_course FOREIGN KEY (course_id) REFERENCES courses(course_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS transcripts (
  transcript_id CHAR(36) PRIMARY KEY,
  student_id CHAR(36) NOT NULL,
  content TEXT,
  gpa DECIMAL(3,2),
  CONSTRAINT fk_transcripts_student FOREIGN KEY (student_id) REFERENCES students(student_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS degree_plans (
  degree_plan_id CHAR(36) PRIMARY KEY,
  student_id CHAR(36) NOT NULL,
  details TEXT,
  CONSTRAINT fk_degreeplans_student FOREIGN KEY (student_id) REFERENCES students(student_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS scholarships (
  scholarship_id CHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  amount DECIMAL(12,2),
  creditRequire VARCHAR(255),
  regulations VARCHAR(255)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS holds (
  hold_id CHAR(36) PRIMARY KEY,
  student_id CHAR(36) NOT NULL,
  reason VARCHAR(255),
  resolved BOOLEAN DEFAULT 0,
  CONSTRAINT fk_holds_student FOREIGN KEY (student_id) REFERENCES students(student_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
SET FOREIGN_KEY_CHECKS=1;
