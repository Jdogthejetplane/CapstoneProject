-- Simple, idempotent seed (MariaDB)

-- College
INSERT INTO colleges (college_id, name, address)
VALUES (UUID(), 'College of STEM', '123 University Ave')
ON DUPLICATE KEY UPDATE address = VALUES(address);

-- Users (keyed by email) — link to college by name
INSERT INTO users (user_id, role, email, password_hash, fname, lname, college_id)
SELECT UUID(), 'student', 'alice.student@example.edu', 'x', 'Alice', 'Student', c.college_id
FROM colleges c WHERE c.name = 'College of STEM'
ON DUPLICATE KEY UPDATE role=VALUES(role), fname=VALUES(fname), lname=VALUES(lname), college_id=VALUES(college_id);

INSERT INTO users (user_id, role, email, password_hash, fname, lname, college_id)
SELECT UUID(), 'advisor', 'bob.advisor@example.edu', 'x', 'Bob', 'Advisor', c.college_id
FROM colleges c WHERE c.name = 'College of STEM'
ON DUPLICATE KEY UPDATE role=VALUES(role), fname=VALUES(fname), lname=VALUES(lname), college_id=VALUES(college_id);

INSERT INTO users (user_id, role, email, password_hash, fname, lname, college_id)
SELECT UUID(), 'leader', 'lisa.leader@example.edu', 'x', 'Lisa', 'Leader', c.college_id
FROM colleges c WHERE c.name = 'College of STEM'
ON DUPLICATE KEY UPDATE role=VALUES(role), fname=VALUES(fname), lname=VALUES(lname), college_id=VALUES(college_id);

-- Roles
INSERT INTO advisors (advisor_id, user_id, percent_advised, rating)
SELECT UUID(), u.user_id, 75.0, 4.8
FROM users u WHERE u.email = 'bob.advisor@example.edu'
ON DUPLICATE KEY UPDATE percent_advised=VALUES(percent_advised), rating=VALUES(rating);

INSERT INTO leaders (leader_id, user_id)
SELECT UUID(), u.user_id
FROM users u WHERE u.email = 'lisa.leader@example.edu'
ON DUPLICATE KEY UPDATE user_id=VALUES(user_id);

INSERT INTO students (student_id, user_id, credit_hrs, gpa, advising_status, last_advised, activity)
SELECT UUID(), u.user_id, 45, 3.42, 'Active', NOW(), 'Created base record'
FROM users u WHERE u.email = 'alice.student@example.edu'
ON DUPLICATE KEY UPDATE credit_hrs=VALUES(credit_hrs), gpa=VALUES(gpa),
  advising_status=VALUES(advising_status), last_advised=VALUES(last_advised), activity=VALUES(activity);

-- Courses (keyed by code)
INSERT INTO courses (course_id, college_id, code, title, credits, difficulty)
SELECT UUID(), c.college_id, 'CS-2013', 'Database Systems I', 3, 3
FROM colleges c WHERE c.name = 'College of STEM'
ON DUPLICATE KEY UPDATE title=VALUES(title), credits=VALUES(credits), difficulty=VALUES(difficulty);

INSERT INTO courses (course_id, college_id, code, title, credits, difficulty)
SELECT UUID(), c.college_id, 'CS-2033', 'Web Systems', 3, 3
FROM colleges c WHERE c.name = 'College of STEM'
ON DUPLICATE KEY UPDATE title=VALUES(title), credits=VALUES(credits), difficulty=VALUES(difficulty);

-- One class for CS-2013
INSERT INTO classes (id, course_id, year, semester, length, time, location, teacher)
SELECT UUID(), crs.course_id, '2025-01-01', 'SP25', 50, '10:00:00', 'ENG 201', 'Dr. Smith'
FROM courses crs WHERE crs.code='CS-2013'
ON DUPLICATE KEY UPDATE length=VALUES(length), teacher=VALUES(teacher), location=VALUES(location);

-- Student docs
INSERT INTO transcripts (transcript_id, student_id, content, gpa)
SELECT UUID(), s.student_id, 'Initial transcript', 3.42
FROM students s
JOIN users u ON u.user_id=s.user_id AND u.email='alice.student@example.edu'
ON DUPLICATE KEY UPDATE content=VALUES(content), gpa=VALUES(gpa);

INSERT INTO degree_plans (degree_plan_id, student_id, details)
SELECT UUID(), s.student_id, 'Start plan'
FROM students s
JOIN users u ON u.user_id=s.user_id AND u.email='alice.student@example.edu'
ON DUPLICATE KEY UPDATE details=VALUES(details);

INSERT INTO schedules (schedule_id, student_id, semester, status)
SELECT UUID(), s.student_id, 'SP25', 'Created'
FROM students s
JOIN users u ON u.user_id=s.user_id AND u.email='alice.student@example.edu'
ON DUPLICATE KEY UPDATE status=VALUES(status);

-- Advisor availability
INSERT INTO availability_slots (slot_id, owner_user_id, day_of_week, start_time, end_time)
SELECT UUID(), u.user_id, 1, '09:00:00', '11:00:00'
FROM users u WHERE u.email='bob.advisor@example.edu'
ON DUPLICATE KEY UPDATE end_time=VALUES(end_time);

-- Scholarship & Hold
INSERT INTO scholarships (scholarship_id, name, amount, creditRequire, regulations)
VALUES (UUID(), 'Merit Scholarship', 1500.00, '12+ credits', 'Good standing')
ON DUPLICATE KEY UPDATE amount=VALUES(amount), creditRequire=VALUES(creditRequire), regulations=VALUES(regulations);

INSERT INTO holds (hold_id, student_id, reason, resolved)
SELECT UUID(), s.student_id, 'Advising required', 0
FROM students s
JOIN users u ON u.user_id=s.user_id AND u.email='alice.student@example.edu'
ON DUPLICATE KEY UPDATE reason=VALUES(reason), resolved=VALUES(resolved);

-- Event & Notification
INSERT INTO events (event_id, kind, payload)
VALUES (UUID(), 'schedule_created', JSON_OBJECT('semester','SP25'))
ON DUPLICATE KEY UPDATE payload=VALUES(payload);

INSERT INTO notifications (notification_id, type, message, target_users_id, source_events_id)
SELECT UUID(), 'info', 'Your schedule was created.', u.user_id,
       (SELECT e.event_id FROM events e WHERE e.kind='schedule_created' ORDER BY e.event_id DESC LIMIT 1)
FROM users u WHERE u.email='alice.student@example.edu'
ON DUPLICATE KEY UPDATE message=VALUES(message);
