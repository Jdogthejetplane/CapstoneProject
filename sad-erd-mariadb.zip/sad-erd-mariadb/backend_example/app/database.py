from fastapi import FastAPI, Depends
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import os

DB_USER = os.getenv("MYSQL_USER", "sad_app")
DB_PASS = os.getenv("MYSQL_PASSWORD", "devapppassword")
DB_HOST = os.getenv("DB_HOST", "db")
DB_PORT = os.getenv("DB_PORT", "3306")
DB_NAME = os.getenv("MYSQL_DATABASE", "sad")

DATABASE_URL = f"mariadb+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"

engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/healthz")
def healthz(db = Depends(get_db)):
    with db.begin():
        ok = db.execute(text("SELECT 1")).scalar() == 1
        return {"db": ok}

@app.get("/students")
def students(db = Depends(get_db)):
    with db.begin():
        rows = db.execute(text("SELECT * FROM v_student_overview")).mappings().all()
        return {"students": [dict(r) for r in rows]}
