pip install fastapi uvicorn sqlalchemy pymysql
DB_HOST=127.0.0.1 DB_PORT=${MARIADB_PORT:-3307} uvicorn app.database:app --reload --port 9000
curl http://localhost:9000/healthz
curl http://localhost:9000/students
