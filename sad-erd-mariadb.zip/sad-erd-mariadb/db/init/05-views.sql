CREATE OR REPLACE VIEW v_student_overview AS
SELECT s.student_id, u.email,
       CONCAT_WS(' ', u.fname, u.lname) AS display_name,
       s.credit_hrs, s.gpa, s.advising_status, s.last_advised
FROM students s
JOIN users u ON u.user_id = s.user_id;
