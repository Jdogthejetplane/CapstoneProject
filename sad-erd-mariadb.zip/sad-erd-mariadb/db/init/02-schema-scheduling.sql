SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE IF NOT EXISTS availability_slots (
  slot_id CHAR(36) PRIMARY KEY,
  owner_user_id CHAR(36) NOT NULL,
  day_of_week TINYINT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  CONSTRAINT fk_avail_owner FOREIGN KEY (owner_user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS schedules (
  schedule_id CHAR(36) PRIMARY KEY,
  student_id CHAR(36) NOT NULL,
  semester VARCHAR(32),
  advisor_id CHAR(36),
  leader_id CHAR(36),
  status VARCHAR(32),
  CONSTRAINT fk_schedules_student FOREIGN KEY (student_id) REFERENCES students(student_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_schedules_advisor FOREIGN KEY (advisor_id) REFERENCES advisors(advisor_id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_schedules_leader FOREIGN KEY (leader_id) REFERENCES leaders(leader_id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;
SET FOREIGN_KEY_CHECKS=1;
