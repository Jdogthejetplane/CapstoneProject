INSERT INTO colleges (college_id, name, address)
  VALUES (UUID(), 'College of STEM', '123 University Ave')
  ON DUPLICATE KEY UPDATE name=name;
INSERT INTO users (user_id, role, email, password_hash, fname, lname, college_id)
  VALUES
    (UUID(), 'student', 'alice.student@example.edu', 'x', 'Alice', 'Student', (SELECT college_id FROM colleges LIMIT 1)),
    (UUID(), 'advisor', 'bob.advisor@example.edu', 'x', 'Bob', 'Advisor', (SELECT college_id FROM colleges LIMIT 1)),
    (UUID(), 'leader',  'lisa.leader@example.edu',  'x', 'Lisa', 'Leader',  (SELECT college_id FROM colleges LIMIT 1))
  ON DUPLICATE KEY UPDATE email=email;
INSERT INTO advisors (advisor_id, user_id, percent_advised, rating)
  SELECT UUID(), u.user_id, 75.0, 4.8 FROM users u WHERE role='advisor'
  ON DUPLICATE KEY UPDATE rating=VALUES(rating);
INSERT INTO leaders (leader_id, user_id)
  SELECT UUID(), u.user_id FROM users u WHERE role='leader'
  ON DUPLICATE KEY UPDATE user_id=user_id;
INSERT INTO students (student_id, user_id, credit_hrs, gpa, advising_status, last_advised, activity)
  SELECT UUID(), u.user_id, 45, 3.42, 'Active', NOW(), 'Created base record' FROM users u WHERE role='student'
  ON DUPLICATE KEY UPDATE credit_hrs=VALUES(credit_hrs);
INSERT INTO courses (course_id, college_id, code, title, credits, difficulty)
  VALUES
    (UUID(), (SELECT college_id FROM colleges LIMIT 1), 'CS-2013', 'Database Systems I', 3, 3),
    (UUID(), (SELECT college_id FROM colleges LIMIT 1), 'CS-2033', 'Web Systems', 3, 3)
  ON DUPLICATE KEY UPDATE title=VALUES(title);
INSERT INTO classes (id, course_id, year, semester, length, time, location, teacher)
  SELECT UUID(), c.course_id, '2025-01-01', 'SP25', 50, '10:00:00', 'ENG 201', 'Dr. Smith' FROM courses c WHERE c.code='CS-2013'
  ON DUPLICATE KEY UPDATE location=VALUES(location);
INSERT INTO transcripts (transcript_id, student_id, content, gpa)
  SELECT UUID(), s.student_id, 'Initial transcript', 3.42 FROM students s
  ON DUPLICATE KEY UPDATE gpa=VALUES(gpa);
INSERT INTO degree_plans (degree_plan_id, student_id, details)
  SELECT UUID(), s.student_id, 'Start plan' FROM students s
  ON DUPLICATE KEY UPDATE details=VALUES(details);
INSERT INTO schedules (schedule_id, student_id, semester, status)
  SELECT UUID(), s.student_id, 'SP25', 'Created' FROM students s
  ON DUPLICATE KEY UPDATE status=VALUES(status);
INSERT INTO availability_slots (slot_id, owner_user_id, day_of_week, start_time, end_time)
  SELECT UUID(), u.user_id, 1, '09:00:00', '11:00:00' FROM users u WHERE role='advisor'
  ON DUPLICATE KEY UPDATE end_time=VALUES(end_time);
INSERT INTO scholarships (scholarship_id, name, amount, creditRequire, regulations)
  VALUES (UUID(), 'Merit Scholarship', 1500.00, '12+ credits', 'Good standing')
  ON DUPLICATE KEY UPDATE amount=VALUES(amount);
INSERT INTO holds (hold_id, student_id, reason, resolved)
  SELECT UUID(), s.student_id, 'Advising required', 0 FROM students s
  ON DUPLICATE KEY UPDATE reason=VALUES(reason);
INSERT INTO events (event_id, kind, payload) VALUES (UUID(), 'schedule_created', JSON_OBJECT('semester','SP25'))
  ON DUPLICATE KEY UPDATE kind=VALUES(kind);
INSERT INTO notifications (notification_id, type, message, target_users_id, source_events_id)
  SELECT UUID(), 'info', 'Your schedule was created.', u.user_id, (SELECT event_id FROM events ORDER BY created_at DESC LIMIT 1)
  FROM users u WHERE role='student'
  ON DUPLICATE KEY UPDATE message=VALUES(message);
