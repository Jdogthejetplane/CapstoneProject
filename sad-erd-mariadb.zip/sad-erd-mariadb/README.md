# SAD ERD-Aligned MariaDB + Docker
- UUID primary keys across all tables
- Modular SQL by concern (core, scheduling, academics, communication, views)
- Adminer, seed data, backups, and a tiny FastAPI example

## Quick start
cp .env.example .env
docker compose --profile dev up -d
make sql
SHOW TABLES;
SELECT * FROM v_student_overview;
