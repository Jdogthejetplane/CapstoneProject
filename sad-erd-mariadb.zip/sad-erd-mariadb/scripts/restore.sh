#!/usr/bin/env sh
set -eu
if [ $# -lt 1 ]; then echo "Provide a .sql file."; exit 1; fi
FILE="$1"
if [ ! -f "$FILE" ]; then echo "File not found: $FILE"; exit 1; fi
docker compose exec -T -e MYSQL_PWD="$MYSQL_ROOT_PASSWORD" db sh -c '
  mariadb -u root "$MYSQL_DATABASE"
' < "$FILE"
echo "Restore complete."
