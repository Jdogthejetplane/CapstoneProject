#!/usr/bin/env sh
set -eu
TS=$(date +"%Y%m%d-%H%M%S")
FILE="/backups/${MYSQL_DATABASE:-sad}-${TS}.sql"
docker compose exec -e MYSQL_PWD="$MYSQL_ROOT_PASSWORD" db sh -c '
  mysqldump -u root --databases "$MYSQL_DATABASE" > "'"$FILE"'"
'
echo "Backup written to $FILE."
