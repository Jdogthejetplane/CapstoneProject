import os
import pymysql
from fastapi import APIRouter, HTTPException

router = APIRouter()

DB_HOST = os.getenv("DB_HOST", "mariadb")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASS", "example")
DB_NAME = os.getenv("DB_NAME", "college")


def get_conn():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


@router.get("/student_overview")
def list_student_overview(limit: int = 100, offset: int = 0):
    sql = "SELECT * FROM v_student_overview LIMIT %s OFFSET %s"
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, [limit, offset])
            return cur.fetchall()

