import os
import pymysql
from typing import Dict, Any, List
from fastapi import APIRouter, HTTPException, Request

router = APIRouter()

DB_HOST = os.getenv("DB_HOST", "mariadb")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASS", "example")
DB_NAME = os.getenv("DB_NAME", "college")


def get_conn():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


# ---------- helpers ----------
def _build_filters(params: Dict[str, Any], allowed_cols: List[str]):
    clauses, values = [], []
    for k, v in params.items():
        if k in ("limit", "offset"):
            continue
        if k in allowed_cols:
            clauses.append(f"{k}=%s")
            values.append(v)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", values


def _insert(conn, table: str, allowed_cols: List[str], data: Dict[str, Any]):
    cols = [c for c in data.keys() if c in allowed_cols]
    if not cols:
        raise HTTPException(400, "No allowed columns in payload")
    placeholders = ",".join(["%s"] * len(cols))
    sql = f"INSERT INTO {table} (" + ",".join(cols) + ") VALUES (" + placeholders + ")"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in cols])
    return {"inserted": True}


def _update(
    conn,
    table: str,
    pk: str,
    allowed_cols: List[str],
    pk_value: str,
    data: Dict[str, Any],
):
    sets = [c for c in data.keys() if c in allowed_cols and c != pk]
    if not sets:
        raise HTTPException(400, "No updatable columns in payload")
    set_clause = ",".join([f"{c}=%s" for c in sets])
    sql = f"UPDATE {table} SET {set_clause} WHERE {pk}=%s"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in sets] + [pk_value])
    return {"updated": True}


def _delete(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"DELETE FROM {table} WHERE {pk}=%s", [pk_value])
    return {"deleted": True}


def _list(
    conn,
    table: str,
    allowed_cols: List[str],
    params: Dict[str, Any],
    limit: int,
    offset: int,
):
    where, values = _build_filters(params, allowed_cols)
    sql = f"SELECT * FROM {table}{where} LIMIT %s OFFSET %s"
    with conn.cursor() as cur:
        cur.execute(sql, values + [limit, offset])
        return cur.fetchall()


def _get_one(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"SELECT * FROM {table} WHERE {pk}=%s", [pk_value])
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Not found")
        return row


# ---------- tables ----------
COLLEGES_COLS = [
    "college_id",
    "name",
    "address",
    "transcripConnect",
    "majorConnection",
    "classConnection",
]


@router.get("/colleges")
def list_colleges(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "colleges", COLLEGES_COLS, params, limit, offset)


@router.get("/colleges/{college_id}")
def get_college(college_id: str):
    with get_conn() as conn:
        return _get_one(conn, "colleges", "college_id", college_id)


@router.post("/colleges")
def create_college(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "colleges", COLLEGES_COLS, payload)


@router.patch("/colleges/{college_id}")
def update_college(college_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn, "colleges", "college_id", COLLEGES_COLS, college_id, payload
        )


@router.delete("/colleges/{college_id}")
def delete_college(college_id: str):
    with get_conn() as conn:
        return _delete(conn, "colleges", "college_id", college_id)


USERS_COLS = [
    "user_id",
    "role",
    "email",
    "password_hash",
    "fname",
    "lname",
    "college_id",
]


@router.get("/users")
def list_users(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "users", USERS_COLS, params, limit, offset)


@router.get("/users/{user_id}")
def get_user(user_id: str):
    with get_conn() as conn:
        return _get_one(conn, "users", "user_id", user_id)


@router.post("/users")
def create_user(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "users", USERS_COLS, payload)


@router.patch("/users/{user_id}")
def update_user(user_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(conn, "users", "user_id", USERS_COLS, user_id, payload)


@router.delete("/users/{user_id}")
def delete_user(user_id: str):
    with get_conn() as conn:
        return _delete(conn, "users", "user_id", user_id)


LEADERS_COLS = ["leader_id", "user_id"]


@router.get("/leaders")
def list_leaders(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "leaders", LEADERS_COLS, params, limit, offset)


@router.get("/leaders/{leader_id}")
def get_leader(leader_id: str):
    with get_conn() as conn:
        return _get_one(conn, "leaders", "leader_id", leader_id)


@router.post("/leaders")
def create_leader(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "leaders", LEADERS_COLS, payload)


@router.patch("/leaders/{leader_id}")
def update_leader(leader_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(conn, "leaders", "leader_id", LEADERS_COLS, leader_id, payload)


@router.delete("/leaders/{leader_id}")
def delete_leader(leader_id: str):
    with get_conn() as conn:
        return _delete(conn, "leaders", "leader_id", leader_id)


ADVISORS_COLS = ["advisor_id", "user_id", "percent_advised", "rating"]


@router.get("/advisors")
def list_advisors(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "advisors", ADVISORS_COLS, params, limit, offset)


@router.get("/advisors/{advisor_id}")
def get_advisor(advisor_id: str):
    with get_conn() as conn:
        return _get_one(conn, "advisors", "advisor_id", advisor_id)


@router.post("/advisors")
def create_advisor(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "advisors", ADVISORS_COLS, payload)


@router.patch("/advisors/{advisor_id}")
def update_advisor(advisor_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn, "advisors", "advisor_id", ADVISORS_COLS, advisor_id, payload
        )


@router.delete("/advisors/{advisor_id}")
def delete_advisor(advisor_id: str):
    with get_conn() as conn:
        return _delete(conn, "advisors", "advisor_id", advisor_id)


STUDENTS_COLS = [
    "student_id",
    "user_id",
    "credit_hrs",
    "gpa",
    "advising_status",
    "last_advised",
    "activity",
    "transcript_id",
    "scholarship_ids",
]


@router.get("/students")
def list_students(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "students", STUDENTS_COLS, params, limit, offset)


@router.get("/students/{student_id}")
def get_student(student_id: str):
    with get_conn() as conn:
        return _get_one(conn, "students", "student_id", student_id)


@router.post("/students")
def create_student(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "students", STUDENTS_COLS, payload)


@router.patch("/students/{student_id}")
def update_student(student_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn, "students", "student_id", STUDENTS_COLS, student_id, payload
        )


@router.delete("/students/{student_id}")
def delete_student(student_id: str):
    with get_conn() as conn:
        return _delete(conn, "students", "student_id", student_id)

