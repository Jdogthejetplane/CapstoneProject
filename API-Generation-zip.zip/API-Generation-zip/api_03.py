import os
import pymysql
from typing import Dict, Any, List
from fastapi import APIRouter, HTTPException, Request

router = APIRouter()

DB_HOST = os.getenv("DB_HOST", "mariadb")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASS", "example")
DB_NAME = os.getenv("DB_NAME", "college")


def get_conn():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


def _build_filters(params: Dict[str, Any], allowed_cols: List[str]):
    clauses, values = [], []
    for k, v in params.items():
        if k in ("limit", "offset"):
            continue
        if k in allowed_cols:
            clauses.append(f"{k}=%s")
            values.append(v)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", values


def _insert(conn, table: str, allowed_cols: List[str], data: Dict[str, Any]):
    cols = [c for c in data.keys() if c in allowed_cols]
    if not cols:
        raise HTTPException(400, "No allowed columns in payload")
    placeholders = ",".join(["%s"] * len(cols))
    sql = f"INSERT INTO {table} (" + ",".join(cols) + ") VALUES (" + placeholders + ")"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in cols])
    return {"inserted": True}


def _update(
    conn,
    table: str,
    pk: str,
    allowed_cols: List[str],
    pk_value: str,
    data: Dict[str, Any],
):
    sets = [c for c in data.keys() if c in allowed_cols and c != pk]
    if not sets:
        raise HTTPException(400, "No updatable columns in payload")
    set_clause = ",".join([f"{c}=%s" for c in sets])
    sql = f"UPDATE {table} SET {set_clause} WHERE {pk}=%s"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in sets] + [pk_value])
    return {"updated": True}


def _delete(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"DELETE FROM {table} WHERE {pk}=%s", [pk_value])
    return {"deleted": True}


def _list(
    conn,
    table: str,
    allowed_cols: List[str],
    params: Dict[str, Any],
    limit: int,
    offset: int,
):
    where, values = _build_filters(params, allowed_cols)
    sql = f"SELECT * FROM {table}{where} LIMIT %s OFFSET %s"
    with conn.cursor() as cur:
        cur.execute(sql, values + [limit, offset])
        return cur.fetchall()


def _get_one(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"SELECT * FROM {table} WHERE {pk}=%s", [pk_value])
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Not found")
        return row


# courses
COURSES_COLS = ["course_id", "college_id", "code", "title", "credits", "difficulty"]


@router.get("/courses")
def list_courses(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "courses", COURSES_COLS, params, limit, offset)


@router.get("/courses/{course_id}")
def get_course(course_id: str):
    with get_conn() as conn:
        return _get_one(conn, "courses", "course_id", course_id)


@router.post("/courses")
def create_course(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "courses", COURSES_COLS, payload)


@router.patch("/courses/{course_id}")
def update_course(course_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(conn, "courses", "course_id", COURSES_COLS, course_id, payload)


@router.delete("/courses/{course_id}")
def delete_course(course_id: str):
    with get_conn() as conn:
        return _delete(conn, "courses", "course_id", course_id)


# classes
CLASSES_COLS = [
    "id",
    "course_id",
    "year",
    "semester",
    "length",
    "time",
    "location",
    "teacher",
]


@router.get("/classes")
def list_classes(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "classes", CLASSES_COLS, params, limit, offset)


@router.get("/classes/{id}")
def get_class(id: str):
    with get_conn() as conn:
        return _get_one(conn, "classes", "id", id)


@router.post("/classes")
def create_class(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "classes", CLASSES_COLS, payload)


@router.patch("/classes/{id}")
def update_class(id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(conn, "classes", "id", CLASSES_COLS, id, payload)


@router.delete("/classes/{id}")
def delete_class(id: str):
    with get_conn() as conn:
        return _delete(conn, "classes", "id", id)


# transcripts
TRANSCRIPTS_COLS = ["transcript_id", "student_id", "content", "gpa"]


@router.get("/transcripts")
def list_transcripts(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "transcripts", TRANSCRIPTS_COLS, params, limit, offset)


@router.get("/transcripts/{transcript_id}")
def get_transcript(transcript_id: str):
    with get_conn() as conn:
        return _get_one(conn, "transcripts", "transcript_id", transcript_id)


@router.post("/transcripts")
def create_transcript(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "transcripts", TRANSCRIPTS_COLS, payload)


@router.patch("/transcripts/{transcript_id}")
def update_transcript(transcript_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn,
            "transcripts",
            "transcript_id",
            TRANSCRIPTS_COLS,
            transcript_id,
            payload,
        )


@router.delete("/transcripts/{transcript_id}")
def delete_transcript(transcript_id: str):
    with get_conn() as conn:
        return _delete(conn, "transcripts", "transcript_id", transcript_id)


# degree_plans
DEGREE_PLANS_COLS = ["degree_plan_id", "student_id", "details"]


@router.get("/degree_plans")
def list_degree_plans(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "degree_plans", DEGREE_PLANS_COLS, params, limit, offset)


@router.get("/degree_plans/{degree_plan_id}")
def get_degree_plan(degree_plan_id: str):
    with get_conn() as conn:
        return _get_one(conn, "degree_plans", "degree_plan_id", degree_plan_id)


@router.post("/degree_plans")
def create_degree_plan(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "degree_plans", DEGREE_PLANS_COLS, payload)


@router.patch("/degree_plans/{degree_plan_id}")
def update_degree_plan(degree_plan_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn,
            "degree_plans",
            "degree_plan_id",
            DEGREE_PLANS_COLS,
            degree_plan_id,
            payload,
        )


@router.delete("/degree_plans/{degree_plan_id}")
def delete_degree_plan(degree_plan_id: str):
    with get_conn() as conn:
        return _delete(conn, "degree_plans", "degree_plan_id", degree_plan_id)


# scholarships
SCHOLARSHIPS_COLS = ["scholarship_id", "name", "amount", "creditRequire", "regulations"]


@router.get("/scholarships")
def list_scholarships(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "scholarships", SCHOLARSHIPS_COLS, params, limit, offset)


@router.get("/scholarships/{scholarship_id}")
def get_scholarship(scholarship_id: str):
    with get_conn() as conn:
        return _get_one(conn, "scholarships", "scholarship_id", scholarship_id)


@router.post("/scholarships")
def create_scholarship(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "scholarships", SCHOLARSHIPS_COLS, payload)


@router.patch("/scholarships/{scholarship_id}")
def update_scholarship(scholarship_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn,
            "scholarships",
            "scholarship_id",
            SCHOLARSHIPS_COLS,
            scholarship_id,
            payload,
        )


@router.delete("/scholarships/{scholarship_id}")
def delete_scholarship(scholarship_id: str):
    with get_conn() as conn:
        return _delete(conn, "scholarships", "scholarship_id", scholarship_id)


# holds
HOLDS_COLS = ["hold_id", "student_id", "reason", "resolved"]


@router.get("/holds")
def list_holds(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "holds", HOLDS_COLS, params, limit, offset)


@router.get("/holds/{hold_id}")
def get_hold(hold_id: str):
    with get_conn() as conn:
        return _get_one(conn, "holds", "hold_id", hold_id)


@router.post("/holds")
def create_hold(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "holds", HOLDS_COLS, payload)


@router.patch("/holds/{hold_id}")
def update_hold(hold_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(conn, "holds", "hold_id", HOLDS_COLS, hold_id, payload)


@router.delete("/holds/{hold_id}")
def delete_hold(hold_id: str):
    with get_conn() as conn:
        return _delete(conn, "holds", "hold_id", hold_id)

