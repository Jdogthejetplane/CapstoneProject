import os
import pymysql
from typing import Dict, Any, List
from fastapi import APIRouter, HTTPException, Request

router = APIRouter()

DB_HOST = os.getenv("DB_HOST", "mariadb")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASS", "example")
DB_NAME = os.getenv("DB_NAME", "college")


def get_conn():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


def _build_filters(params: Dict[str, Any], allowed_cols: List[str]):
    clauses, values = [], []
    for k, v in params.items():
        if k in ("limit", "offset"):
            continue
        if k in allowed_cols:
            clauses.append(f"{k}=%s")
            values.append(v)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", values


def _insert(conn, table: str, allowed_cols: List[str], data: Dict[str, Any]):
    cols = [c for c in data.keys() if c in allowed_cols]
    if not cols:
        raise HTTPException(400, "No allowed columns in payload")
    placeholders = ",".join(["%s"] * len(cols))
    sql = f"INSERT INTO {table} (" + ",".join(cols) + ") VALUES (" + placeholders + ")"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in cols])
    return {"inserted": True}


def _update(
    conn,
    table: str,
    pk: str,
    allowed_cols: List[str],
    pk_value: str,
    data: Dict[str, Any],
):
    sets = [c for c in data.keys() if c in allowed_cols and c != pk]
    if not sets:
        raise HTTPException(400, "No updatable columns in payload")
    set_clause = ",".join([f"{c}=%s" for c in sets])
    sql = f"UPDATE {table} SET {set_clause} WHERE {pk}=%s"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in sets] + [pk_value])
    return {"updated": True}


def _delete(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"DELETE FROM {table} WHERE {pk}=%s", [pk_value])
    return {"deleted": True}


def _list(
    conn,
    table: str,
    allowed_cols: List[str],
    params: Dict[str, Any],
    limit: int,
    offset: int,
):
    where, values = _build_filters(params, allowed_cols)
    sql = f"SELECT * FROM {table}{where} LIMIT %s OFFSET %s"
    with conn.cursor() as cur:
        cur.execute(sql, values + [limit, offset])
        return cur.fetchall()


def _get_one(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"SELECT * FROM {table} WHERE {pk}=%s", [pk_value])
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Not found")
        return row


# events
EVENTS_COLS = ["event_id", "kind", "payload", "created_at"]


@router.get("/events")
def list_events(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "events", EVENTS_COLS, params, limit, offset)


@router.get("/events/{event_id}")
def get_event(event_id: str):
    with get_conn() as conn:
        return _get_one(conn, "events", "event_id", event_id)


@router.post("/events")
def create_event(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "events", EVENTS_COLS, payload)


@router.patch("/events/{event_id}")
def update_event(event_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(conn, "events", "event_id", EVENTS_COLS, event_id, payload)


@router.delete("/events/{event_id}")
def delete_event(event_id: str):
    with get_conn() as conn:
        return _delete(conn, "events", "event_id", event_id)


# notifications
NOTIFS_COLS = [
    "notification_id",
    "type",
    "message",
    "created_at",
    "is_read",
    "target_users_id",
    "source_events_id",
]


@router.get("/notifications")
def list_notifications(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "notifications", NOTIFS_COLS, params, limit, offset)


@router.get("/notifications/{notification_id}")
def get_notification(notification_id: str):
    with get_conn() as conn:
        return _get_one(conn, "notifications", "notification_id", notification_id)


@router.post("/notifications")
def create_notification(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "notifications", NOTIFS_COLS, payload)


@router.patch("/notifications/{notification_id}")
def update_notification(notification_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn,
            "notifications",
            "notification_id",
            NOTIFS_COLS,
            notification_id,
            payload,
        )


@router.delete("/notifications/{notification_id}")
def delete_notification(notification_id: str):
    with get_conn() as conn:
        return _delete(conn, "notifications", "notification_id", notification_id)

