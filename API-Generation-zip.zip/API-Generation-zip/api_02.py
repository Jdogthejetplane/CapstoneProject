import os
import pymysql
from typing import Dict, Any, List
from fastapi import APIRouter, HTTPException, Request

router = APIRouter()

DB_HOST = os.getenv("DB_HOST", "mariadb")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASS", "example")
DB_NAME = os.getenv("DB_NAME", "college")


def get_conn():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


def _build_filters(params: Dict[str, Any], allowed_cols: List[str]):
    clauses, values = [], []
    for k, v in params.items():
        if k in ("limit", "offset"):
            continue
        if k in allowed_cols:
            clauses.append(f"{k}=%s")
            values.append(v)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", values


def _insert(conn, table: str, allowed_cols: List[str], data: Dict[str, Any]):
    cols = [c for c in data.keys() if c in allowed_cols]
    if not cols:
        raise HTTPException(400, "No allowed columns in payload")
    placeholders = ",".join(["%s"] * len(cols))
    sql = f"INSERT INTO {table} (" + ",".join(cols) + ") VALUES (" + placeholders + ")"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in cols])
    return {"inserted": True}


def _update(
    conn,
    table: str,
    pk: str,
    allowed_cols: List[str],
    pk_value: str,
    data: Dict[str, Any],
):
    sets = [c for c in data.keys() if c in allowed_cols and c != pk]
    if not sets:
        raise HTTPException(400, "No updatable columns in payload")
    set_clause = ",".join([f"{c}=%s" for c in sets])
    sql = f"UPDATE {table} SET {set_clause} WHERE {pk}=%s"
    with conn.cursor() as cur:
        cur.execute(sql, [data[c] for c in sets] + [pk_value])
    return {"updated": True}


def _delete(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"DELETE FROM {table} WHERE {pk}=%s", [pk_value])
    return {"deleted": True}


def _list(
    conn,
    table: str,
    allowed_cols: List[str],
    params: Dict[str, Any],
    limit: int,
    offset: int,
):
    where, values = _build_filters(params, allowed_cols)
    sql = f"SELECT * FROM {table}{where} LIMIT %s OFFSET %s"
    with conn.cursor() as cur:
        cur.execute(sql, values + [limit, offset])
        return cur.fetchall()


def _get_one(conn, table: str, pk: str, pk_value: str):
    with conn.cursor() as cur:
        cur.execute(f"SELECT * FROM {table} WHERE {pk}=%s", [pk_value])
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Not found")
        return row


# availability_slots
AVAIL_COLS = ["slot_id", "owner_user_id", "day_of_week", "start_time", "end_time"]


@router.get("/availability_slots")
def list_availability(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "availability_slots", AVAIL_COLS, params, limit, offset)


@router.get("/availability_slots/{slot_id}")
def get_availability(slot_id: str):
    with get_conn() as conn:
        return _get_one(conn, "availability_slots", "slot_id", slot_id)


@router.post("/availability_slots")
def create_availability(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "availability_slots", AVAIL_COLS, payload)


@router.patch("/availability_slots/{slot_id}")
def update_availability(slot_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn, "availability_slots", "slot_id", AVAIL_COLS, slot_id, payload
        )


@router.delete("/availability_slots/{slot_id}")
def delete_availability(slot_id: str):
    with get_conn() as conn:
        return _delete(conn, "availability_slots", "slot_id", slot_id)


# schedules
SCHEDULES_COLS = [
    "schedule_id",
    "student_id",
    "semester",
    "advisor_id",
    "leader_id",
    "status",
]


@router.get("/schedules")
def list_schedules(request: Request, limit: int = 100, offset: int = 0):
    params = dict(request.query_params)
    with get_conn() as conn:
        return _list(conn, "schedules", SCHEDULES_COLS, params, limit, offset)


@router.get("/schedules/{schedule_id}")
def get_schedule(schedule_id: str):
    with get_conn() as conn:
        return _get_one(conn, "schedules", "schedule_id", schedule_id)


@router.post("/schedules")
def create_schedule(payload: Dict[str, Any]):
    with get_conn() as conn:
        return _insert(conn, "schedules", SCHEDULES_COLS, payload)


@router.patch("/schedules/{schedule_id}")
def update_schedule(schedule_id: str, payload: Dict[str, Any]):
    with get_conn() as conn:
        return _update(
            conn, "schedules", "schedule_id", SCHEDULES_COLS, schedule_id, payload
        )


@router.delete("/schedules/{schedule_id}")
def delete_schedule(schedule_id: str):
    with get_conn() as conn:
        return _delete(conn, "schedules", "schedule_id", schedule_id)

