from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api_01 import router as core_router
from api_02 import router as scheduling_router
from api_03 import router as academics_router
from api_04 import router as comms_router
from api_05 import router as views_router

app = FastAPI(title="SAD-API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(core_router, prefix="/api/core", tags=["core"])
app.include_router(scheduling_router, prefix="/api/scheduling", tags=["scheduling"])
app.include_router(academics_router, prefix="/api/academics", tags=["academics"])
app.include_router(comms_router, prefix="/api/communication", tags=["communication"])
app.include_router(views_router, prefix="/api/views", tags=["views"])


@app.get("/")
def root():
    return {"ok": True, "service": "SAD-API"}

