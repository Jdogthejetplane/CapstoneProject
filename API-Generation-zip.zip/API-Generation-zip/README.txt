============================================================
1) OVERVIEW
============================================================
- FastAPI app exposes CRUD endpoints for our tables
- Direct MariaDB access via PyMySQL 
- One router/module per schema file:
    /api/core         (users, students, etc.)
    /api/scheduling   (availability_slots, schedules)
    /api/academics    (courses, classes, transcripts, degree_plans, scholarships, holds)
    /api/communication(events, notifications)
    /api/views        
- CORS is open (so React on localhost can call it)

============================================================
2) HOW THE CODE IS ORGANIZED
============================================================

- main.py
   - Creates the FastAPI app
   - Adds CORS
   - Includes routers:
       from api_01 import router as core_router
       from api_02 import router as scheduling_router
       from api_03 import router as academics_router
       from api_04 import router as comms_router
       from api_05 import router as views_router
   - Routers are grabbed from API files 

- api_01.py ... api_05.py
   - Each file:
       - Defines DB connection (reads env vars)
       - Simple helpers for SELECT/INSERT/UPDATE/DELETE
       - One “allowed columns” list per table to prevent SQL injection
       - Endpoints:
           GET    /table           (list with filters + pagination)
           GET    /table/{id}      (by primary key)
           POST   /table           (insert row)
           PATCH  /table/{id}      (partial update)
           DELETE /table/{id}      (delete)

- Dockerfile
   - Installs requirements and launches uvicorn server on port 8000

- requirements.txt
   - fastapi, uvicorn, pymysql

============================================================
3) HOW JSON + FASTAPI WORK 
============================================================
- Requests and responses are plain JSON.
- POST/PATCH bodies are just JSON objects where keys = column names.
  Example POST /api/core/users body:
  {
    "user_id": "uuid-here",
    "role": "student",
    "email": "sam@example.edu",
    "password_hash": "x",
    "fname": "Sam",
    "lname": "Lee",
    "college_id": "uuid-of-existing-college"
  }

- IMPORTANT: IDs are CHAR(36) UUIDs. We don’t generate them in the API.
  You must send a UUID in POSTs when a PK is required.

- Filtering: Any query param matching a column name becomes an equality
  filter. Example:
  GET /api/core/users?role=student&limit=50



============================================================
4) RUN THE API CONTAINER
============================================================


Run database container before API container



  docker compose up -d --build
Check:
  curl http://localhost:8000/   -> {"ok":true,"service":"SAD-API"}

============================================================
5) TESTING COMMANDS
============================================================
Users:
- List (limit & filters):
  curl "http://localhost:8000/api/core/users?limit=5&role=student"

- Get by id:
  curl "http://localhost:8000/api/core/users/<user-id>"

- Create:
  curl -X POST http://localhost:8000/api/core/users \
    -H "Content-Type: application/json" \
    -d '{
      "user_id":"00000000-0000-0000-0000-000000000001",
      "role":"student",
      "email":"test@example.edu",
      "password_hash":"x",
      "fname":"Test",
      "lname":"User",
      "college_id":"<existing-college-uuid>"
    }'

- Update:
  curl -X PATCH http://localhost:8000/api/core/users/<user-id> \
    -H "Content-Type: application/json" \
    -d '{"lname":"Userson"}'

- Delete:
  curl -X DELETE http://localhost:8000/api/core/users/<user-id>

Courses:
- List:
  curl "http://localhost:8000/api/academics/courses?limit=5"

View:
- Student overview view:
  curl "http://localhost:8000/api/views/student_overview?limit=5&offset=0"



============================================================
6) BUILDING GENERAL APIs 
============================================================



Create new file named approprietely for new API's, we can group similar API's together. 


For every API file created, create a router in the file. This allows main.py to route from other .py files. 

Create a router 
   ------------------------------------------------
   # api_misc.py
   from fastapi import APIRouter, HTTPException

   router = APIRouter()

   @router.get("/ping")
   def ping():
       return {"pong": True}

   @router.get("/echo")
   def echo(msg: str = "hello"):
       return {"echo": msg}

   ------------------------------------------------
main.py router import
   ------------------------------------------------
   from api_misc import router as misc_router
   app.include_router(misc_router, prefix="/api/misc", tags=["misc"])
   ------------------------------------------------

Test with curl
   ------------------------------------------------
   # health
   curl http://localhost:8000/api/misc/ping

   # query params
   curl "http://localhost:8000/api/misc/echo?msg=hi-there"


   ------------------------------------------------


   - Return plain dicts/lists; FastAPI turns them into JSON.



============================================================
7) FRONTEND (REACT) 
============================================================
Testing code I used to print to app

// src/App.tsx
import { useEffect, useState } from "react";
const API_BASE = process.env.REACT_APP_API_URL ?? "http://localhost:8000";
export default function App() {
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    fetch(`${API_BASE}/api/core/users?limit=5`)
      .then(r => (r.ok ? r.json() : Promise.reject(r.statusText)))
      .then(setData)
      .catch(console.error);
  }, []);
  return <pre>{JSON.stringify(data, null, 2)}</pre>;
}


This just prints raw JSON. To point to other endpoints, change the fetch URL. It will grab data dynamically. 



