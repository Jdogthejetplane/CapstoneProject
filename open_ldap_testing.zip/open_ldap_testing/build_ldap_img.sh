#!/bin/bash

#Install and Enable Docker
if ! command -v docker &> /dev/null; then
    echo "Missing docker... Installing docker..."
    sudo zypper install docker
    sudo systemctl start docker
    sudo systemctl enable docker
    #Adding user to docker group
    echo "Adding user to docker group please enter username"
    read USER
    sudo usermod -aG docker $USER
    newgrp docker
fi
#Run openldap docker image
docker build -t my-openldap .
docker run \
      --name openldap-server \
        -p 389:389 \
        -p 636:636 \
        --hostname ldap.computingforgeeks.com \
	    --env LDAP_ORGANISATION="uafs" \
	    --env LDAP_DOMAIN="uafs.edu" \
	    --env LDAP_ADMIN_PASSWORD="StrongAdminPassw0rd" \
        --env LDAP_BASE_DN="dc=uafs,dc=edu" \
	--detach my-openldap

#Run phpldap docker image
docker run \
    --name phpldapadmin \
    -p 10080:80 \
    -p 10443:443 \
    --hostname phpldapadmin-service \
    --link openldap-server:ldap-host \
    --env PHPLDAPADMIN_LDAP_HOSTS=ldap.computingforgeeks.com \
    --detach osixia/phpldapadmin:latest

#Opening ports for phpldapadmin
sudo firewall-cmd --add-port=389/tcp --permanent
sudo firewall-cmd --add-port=636/tcp --permanent
sudo firewall-cmd --reload

